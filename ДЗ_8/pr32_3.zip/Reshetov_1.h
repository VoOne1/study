#pragma once
#include"stdafx.h"
class Reshetov_1 : public Reshetov {
public:
    Reshetov* copy();
    Reshetov_1() {}
    Reshetov_1(const Reshetov_1& obj)
    {}
    void change() {}
    ~Reshetov_1() {}
};
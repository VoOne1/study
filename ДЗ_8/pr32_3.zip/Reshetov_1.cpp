#pragma once
#include "stdafx.h"

Reshetov* Reshetov_1::copy() { return new Reshetov_1(*this); }

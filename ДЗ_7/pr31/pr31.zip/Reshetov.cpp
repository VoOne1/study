#include "stdafx.h"

Reshetov::Reshetov(int tmp) :testField(tmp) {  }
Reshetov::Reshetov():testField(0){ }
Reshetov::~Reshetov() {}

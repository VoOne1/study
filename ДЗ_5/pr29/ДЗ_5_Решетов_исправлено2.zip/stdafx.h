#pragma once
#include<iostream>
#include<fstream>
#include<string>
#include<set>
#include<map>
#include<vector> 
#include<algorithm>
#include<cmath>
#include <tchar.h>.
#pragma once
#include "stdafx.h"
void Reshetov_1::copy(class DB& obj, std::list<Reshetov*>& db, std::list<Reshetov*>::iterator it) { it = db.erase(it); }

#pragma once
#include<iostream>
#include<fstream>
#include<string>
#include<set>
#include<map>
#include<list>
#include<vector> 
#include<algorithm>
#include<cmath>
#include <tchar.h>
//#include "pr31.h"
#include "Reshetov.h"
#include "Reshetov_1.h"
#include "Reshetov_2.h"
//#include "Reshetov_3.h"
#include "DB.h"
#define _CRTDBG_MAP_ALLOC
#include <crtdbg.h>


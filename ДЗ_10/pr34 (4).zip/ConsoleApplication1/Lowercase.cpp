#include "stdafx.h"
void Lowercase::copyUpper(class DB& db)
{}
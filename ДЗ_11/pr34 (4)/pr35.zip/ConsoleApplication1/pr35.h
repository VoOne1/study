#pragma once
#include "stdafx.h"
void readFile(DB& db1);
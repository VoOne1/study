#pragma once
#include<iostream>
#include<fstream>
#include<string>
#include<set>
#include<map>
#include<vector> 
#include<algorithm>
#include<cmath>
#include <tchar.h>
#include "pr30.h"
#include "Reshetov_1.h"
#include "Reshetov_2.h"
#define _CRTDBG_MAP_ALLOC
#include <crtdbg.h>


#include "stdafx.h"
void Reshetov_1::print() { std::cout << "fd = " << *fd << " " << "f = " << f << std::endl; }
